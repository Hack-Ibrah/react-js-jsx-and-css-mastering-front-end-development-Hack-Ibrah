import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import TaskManager from './pages/TaskManager'
import ApiList from './pages/ApiList'

export default function App(){
  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100">
      <Navbar />
      <main className="flex-1 py-6">
        <Routes>
          <Route path="/" element={<div className="container mx-auto p-4"><h1 className="text-3xl font-bold">Welcome — Week 3 Project</h1><p className="mt-2">Complete demo app with Tasks, API list, theme switching, responsive layout.</p></div>} />
          <Route path="/tasks" element={<TaskManager />} />
          <Route path="/api" element={<ApiList />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}