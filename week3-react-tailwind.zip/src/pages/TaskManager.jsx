import React, { useState } from 'react'
import useLocalStorage from '../hooks/useLocalStorage'
import Card from '../components/Card'
import Button from '../components/Button'

export default function TaskManager(){
  const [tasks, setTasks] = useLocalStorage('plp_tasks', [])
  const [text, setText] = useState('')
  const [filter, setFilter] = useState('all')

  function addTask(e){
    e.preventDefault()
    if(!text.trim()) return
    const newTask = { id: Date.now(), text: text.trim(), done: false }
    setTasks([newTask, ...tasks])
    setText('')
  }

  function toggle(id){ setTasks(tasks.map(t => t.id === id ? {...t, done: !t.done} : t)) }
  function remove(id){ setTasks(tasks.filter(t => t.id !== id)) }

  const filtered = tasks.filter(t => filter === 'all' ? true : filter === 'active' ? !t.done : t.done)

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Task Manager</h2>
      <Card>
        <form onSubmit={addTask} className="flex gap-2">
          <input value={text} onChange={e=>setText(e.target.value)} placeholder="Add task..." className="flex-1 p-2 rounded border" />
          <Button type="submit">Add</Button>
        </form>
        <div className="mt-4 flex gap-2">
          <Button variant={filter==='all'?'primary':'secondary'} onClick={()=>setFilter('all')}>All</Button>
          <Button variant={filter==='active'?'primary':'secondary'} onClick={()=>setFilter('active')}>Active</Button>
          <Button variant={filter==='completed'?'primary':'secondary'} onClick={()=>setFilter('completed')}>Completed</Button>
        </div>

        <ul className="mt-4 space-y-2">
          {filtered.map(t => (
            <li key={t.id} className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-2 rounded">
              <div className="flex items-center gap-2">
                <input type="checkbox" checked={t.done} onChange={()=>toggle(t.id)} />
                <span className={`${t.done ? 'line-through text-gray-400' : ''}`}>{t.text}</span>
              </div>
              <Button variant="danger" onClick={()=>remove(t.id)}>Delete</Button>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}