import React, { useEffect, useState } from 'react'
import Card from '../components/Card'
import Button from '../components/Button'

export default function ApiList(){
  const [items, setItems] = useState([])
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [q, setQ] = useState('')

  useEffect(() => {
    let cancelled = false
    async function load(){
      setLoading(true); setError(null)
      try{
        const res = await fetch(`https://jsonplaceholder.typicode.com/posts?_page=${page}&_limit=10`)
        const data = await res.json()
        if(!cancelled) setItems(prev => page===1 ? data : [...prev, ...data])
      }catch(err){ if(!cancelled) setError(err.message) }
      finally{ if(!cancelled) setLoading(false) }
    }
    load()
    return ()=> cancelled = true
  }, [page])

  const filtered = items.filter(i => i.title.includes(q) || i.body.includes(q))

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">API Data (JSONPlaceholder)</h2>
      <Card>
        <div className="flex gap-2 mb-4">
          <input placeholder="Search title or body" value={q} onChange={e=>setQ(e.target.value)} className="flex-1 p-2 rounded border" />
          <Button onClick={()=>{ setPage(1); setItems([]) }}>Refresh</Button>
        </div>

        {loading && <div>Loading...</div>}
        {error && <div className="text-red-500">Error: {error}</div>}

        <ul className="space-y-2">
          {filtered.map(item => (
            <li key={item.id} className="p-2 border rounded">
              <h3 className="font-semibold">{item.title}</h3>
              <p className="text-sm">{item.body}</p>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex justify-center gap-2">
          <Button onClick={()=> setPage(p => Math.max(1, p-1)) } disabled={page===1}>Prev</Button>
          <div className="px-3 py-2">Page {page}</div>
          <Button onClick={()=> setPage(p => p+1) }>Next</Button>
        </div>
      </Card>
    </div>
  )
}