import React from 'react'

export default function Button({ children, variant='primary', ...rest }){
  const base = 'px-4 py-2 rounded-md font-semibold transition-transform active:scale-95'
  const variants = {
    primary: 'bg-blue-600 text-white hover:bg-blue-500',
    secondary: 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-100',
    danger: 'bg-red-600 text-white hover:bg-red-500'
  }
  return (
    <button className={`${base} ${variants[variant] || variants.primary}`} {...rest}>
      {children}
    </button>
  )
}