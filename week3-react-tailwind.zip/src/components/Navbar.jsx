import React, { useContext } from 'react'
import { Link } from 'react-router-dom'
import { ThemeContext } from '../context/ThemeContext'
import Button from './Button'

export default function Navbar(){
  const { theme, setTheme } = useContext(ThemeContext)
  return (
    <nav className="bg-white dark:bg-gray-900 shadow p-4">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link to="/" className="font-bold text-lg">Dahlia LMS (Week 3)</Link>
          <Link to="/tasks" className="text-sm">Tasks</Link>
          <Link to="/api" className="text-sm">API</Link>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>Toggle {theme === 'dark' ? 'Light' : 'Dark'}</Button>
        </div>
      </div>
    </nav>
  )
}