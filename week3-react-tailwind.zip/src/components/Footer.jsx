import React from 'react'

export default function Footer(){
  return (
    <footer className="mt-8 py-4 bg-gray-50 dark:bg-gray-900 text-sm">
      <div className="container mx-auto text-center text-gray-600 dark:text-gray-300">
        © {new Date().getFullYear()} Dahlia Training Institute — Built for PLP Week 3
      </div>
    </footer>
  )
}